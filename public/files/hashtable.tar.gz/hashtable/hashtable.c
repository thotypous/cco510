#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "siphash.h"
#include "hashtable.h"

struct elem {
	const char *chave;
	void *valor;
};

void hashtable_new(hashtable *h, int tamanho) {
	FILE *fp = fopen("/dev/urandom", "rb");
	fread(h->segredo, 1, sizeof(h->segredo), fp);
	fclose(fp);

	// arrendonda para próxima potência de 2
	h->disponiveis = 1 << (32 - __builtin_clz(tamanho - 1));

	h->mascara = h->disponiveis - 1;
	h->elems = (elem *) malloc(h->disponiveis * sizeof(elem));
	memset(h->elems, 0, h->disponiveis * sizeof(elem));
}

void hashtable_destroy(hashtable *h) {
	memset(h->segredo, 0, sizeof(h->segredo));
	free(h->elems);
}

static size_t hash(const hashtable *h, const char *chave, size_t len, int tentativa) {
	uint64_t buf[3];
	siphash((uint8_t *) chave, len, (uint8_t *) h->segredo, (uint8_t *) buf, 2*sizeof(buf[0]));
	buf[2] = tentativa;
	siphash((uint8_t *) buf, sizeof(buf), (uint8_t *) h->segredo, (uint8_t *) buf, sizeof(buf[0]));
	return buf[0] & h->mascara;
}

int hashtable_put(hashtable *h, const char *chave, void *valor) {
	// retorna -1 se não tiver mais espaço disponível
	// retorna 0 se inserir o elemento com sucesso
}

void *hashtable_get(const hashtable *h, const char *chave) {
	// retorna o valor do elemento caso encontrá-lo
	// senão, retorna NULL
}
