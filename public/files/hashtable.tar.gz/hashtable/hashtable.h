#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <stdint.h>

typedef struct elem elem;

typedef struct {
	int mascara;
	int disponiveis;
	uint64_t segredo[2];
	elem *elems;
} hashtable;

void hashtable_new(hashtable *h, int tamanho);
void hashtable_destroy(hashtable *h);
int hashtable_put(hashtable *h, const char *chave, void *valor);
void *hashtable_get(const hashtable *h, const char *chave);

#endif
