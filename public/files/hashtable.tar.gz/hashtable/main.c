#include <stdio.h>
#include <assert.h>
#include "hashtable.h"

int main() {
	int res;
	hashtable h;
	hashtable_new(&h, 200);

	res = hashtable_put(&h, "um", "1");
	assert(res == 0);

	res = hashtable_put(&h, "dois", "2");
	assert(res == 0);

	printf("um = %s\n", (char *) hashtable_get(&h, "um"));
	printf("dois = %s\n", (char *) hashtable_get(&h, "dois"));
	printf("tres = %s\n\n", (char *) hashtable_get(&h, "tres"));

	res = hashtable_put(&h, "tres", "3");
	assert(res == 0);

	printf("um = %s\n", (char *) hashtable_get(&h, "um"));
	printf("dois = %s\n", (char *) hashtable_get(&h, "dois"));
	printf("tres = %s\n\n", (char *) hashtable_get(&h, "tres"));

	hashtable_destroy(&h);
	return 0;
}
