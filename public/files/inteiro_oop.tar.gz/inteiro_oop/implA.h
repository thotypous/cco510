#ifndef IMPLA_H
#define IMPLA_H

Inteiro *ImplA_novo();

#endif
