#ifndef IMPLB_H
#define IMPLB_H

Inteiro *ImplB_novo();

#endif
