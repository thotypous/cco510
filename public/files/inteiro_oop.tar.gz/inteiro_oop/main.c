#include <stdio.h>

#include "inteiro.h"
#include "implA.h"
#include "implB.h"

void oi(void *arg) {
	printf("  oi\n");
}

int main() {
	Inteiro *a = ImplA_novo();
	a = a->incrementar(a);
	a = a->incrementar(a);
	printf("Abaixo, deve aparecer 'oi' duas vezes:\n");
	a->repetir(a, oi, NULL);
	printf("\n");

	Inteiro *b = ImplB_novo();
	b = b->incrementar(b);
	b = b->incrementar(b);
	b = b->incrementar(b);
	printf("Abaixo, deve aparecer 'oi' três vezes:\n");
	b->repetir(b, oi, NULL);
	printf("\n");

	Inteiro *c = b->somar(b, a);
	printf("Abaixo, deve aparecer 'oi' cinco vezes:\n");
	c->repetir(c, oi, NULL);
	printf("\n");

	Inteiro *d = a->somar(a, c);
	printf("Abaixo, deve aparecer 'oi' sete vezes:\n");
	d->repetir(d, oi, NULL);
	printf("\n");

	return 0;
}
